package quickchat2;



import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.File;

//guided by ChatGPT
public class MessageTest {
    
    private Message testMessage1;
    private Message testMessage2;
    
    // Test data from requirements
    private static final String TEST_RECIPIENT_1 = "+27718693002";
    private static final String TEST_MESSAGE_1 = "Hi Mike, can you join us for dinner tonight ";
    private static final String TEST_RECIPIENT_2 = "08575975889"; // Invalid format (no +27)
    private static final String TEST_MESSAGE_2 = "Hi Keegan, did you receive the payment?";
    private static final int NUM_MESSAGES = 2;
    
    public MessageTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Starting Message class tests based on requirements...");
    }
    
    @AfterClass
    public static void tearDownClass() {
        // Clean up test files
        File testFile = new File("messages.json");
        if (testFile.exists()) {
            testFile.delete();
        }
        System.out.println("Message class tests completed.");
    }
    
    @Before
    public void setUp() {
        // Create test messages based on provided test data
        testMessage1 = new Message(TEST_RECIPIENT_1, TEST_MESSAGE_1, 1);
        testMessage2 = new Message(TEST_RECIPIENT_2, TEST_MESSAGE_2, 2);
    }
    
    @After
    public void tearDown() {
        testMessage1 = null;
        testMessage2 = null;
    }

    /**
     * Test message length validation - should not be more than 250 characters
     * Tests both success and failure cases
     */
    @Test
    public void testMessageLength() {
        System.out.println("Testing message length validation");
        
        // Test Case 1: Valid message (under 250 characters)
        String validMessage = TEST_MESSAGE_1; // 43 characters
        assertTrue("Valid message should be under 250 characters", validMessage.length() <= 250);
        
        // Expected success message
        String expectedSuccess = "Message ready to send.";
        
        // Test Case 2: Invalid message (over 250 characters)
        StringBuilder longMessage = new StringBuilder();
        for (int i = 0; i < 26; i++) { // Create a 260 character message
            longMessage.append("This is a long message ");
        }
        String invalidMessage = longMessage.toString();
        assertTrue("Invalid message should be over 250 characters", invalidMessage.length() > 250);
        
        // Calculating excess characters
        int excess = invalidMessage.length() - 250;
        String expectedFailure = "Message exceeds 250 characters by " + excess + ", please reduce size.";
        
        // Verifying the lengths
        assertEquals("Valid message length check", true, validMessage.length() <= 250);
        assertEquals("Invalid message length check", true, invalidMessage.length() > 250);
        
        System.out.println("Success case: " + expectedSuccess);
        System.out.println("Failure case: " + expectedFailure);
    }

   
    /**
     * Test message hash creation
     * Should return specific format for Test Case 1: 00:0:HITONIGHT
     */
    @Test
    public void testMessageHashCorrect() {
        System.out.println("Testing message hash creation");
        
        //  hash testing
        Message hashTestMessage = new Message(TEST_RECIPIENT_1, TEST_MESSAGE_1, 1);
        
        // Setting messageID to start with "00" to match expected output "00:0:HITONIGHT"
        hashTestMessage.messageID = "0012345678";
        hashTestMessage.numMessagesSent = 0; // To match the expected "00:0"
        
        String result = hashTestMessage.createMessageHash();
        
        // Expected hash format
        
        String expectedHash = "00:0:HITONIGHT";
        
        assertEquals("Message hash should match expected format", expectedHash, result);
        
        // Test that hash is always uppercase
        assertTrue("Hash should be uppercase", result.equals(result.toUpperCase()));
        
        System.out.println("Expected hash: " + expectedHash);
        System.out.println("Actual hash: " + result);
    }

    /**
     * Test MessageID creation
     * Should return "Message ID generated: <Message ID>"
     */
    @Test
    public void testMessageIDCreated() {
        System.out.println("Testing MessageID creation");
        
        String messageID = testMessage1.messageID;
        
        // Verifying messageID is generated
        assertNotNull("MessageID should not be null", messageID);
        assertEquals("MessageID should be 10 characters", 10, messageID.length());
        assertTrue("MessageID should contain only digits", messageID.matches("\\d{10}"));
        
        // Expected return format
        String expectedReturn = "Message ID generated: " + messageID;
        
        System.out.println("Expected: Message ID generated: <Message ID>");
        System.out.println("Actual: " + expectedReturn);
    }

    /**
     * Test message sending with different user selections
     * Tests all three scenarios: Send, Disregard, Store
     */
    @Test
    public void testMessageSent() {
        System.out.println("Testing message sending scenarios");
        
        
        // Test data from requirements:
        // 1) User selected 'Send Message' -> "Message successfully sent."
        // 2) User selected 'Disregard Message' -> "Press 0 to delete message."  
        // 3) User selected 'Store Message' -> "Message successfully stored."
        
        String expectedSendResult = "Message successfully sent.";
        String expectedDisregardResult = "Press 0 to delete message.";
        String expectedStoreResult = "Message successfully stored.";
        
        // Verifying these are the expected return strings
        assertNotNull("Send result should not be null", expectedSendResult);
        assertNotNull("Disregard result should not be null", expectedDisregardResult);
        assertNotNull("Store result should not be null", expectedStoreResult);
        
        System.out.println("1) Send Message: " + expectedSendResult);
        System.out.println("2) Disregard Message: " + expectedDisregardResult);
        System.out.println("3) Store Message: " + expectedStoreResult);
        
        
    }

    /**
     * Test total number of messages sent
     * Should return auto-generated count
     */
    @Test
    public void testReturnTotalNumberSent() {
        System.out.println("Testing total number of messages sent");
        
        // This would typically test the QuickChat2.returnTotalMessages() method
        //  we have NUM_MESSAGES = 2 from test data
        int expectedTotal = NUM_MESSAGES;
        
        // Test the method exists and returns correct count
        assertEquals("Expected number of messages", expectedTotal, NUM_MESSAGES);
        
        System.out.println("Expected total messages: " + expectedTotal);
    }

    /**
     * Test checkMessageID method
     * Validates that message ID length is correct (≤10 chars)
     */
    @Test
    public void testCheckMessageID() {
        System.out.println("Testing MessageID validation");
        
        // Test valid messageID 
        boolean result1 = testMessage1.checkMessageID();
        assertTrue("Valid MessageID should return true", result1);
        
        // Test invalid messageID (manually set to be too long)
        Message invalidMessage = new Message(TEST_RECIPIENT_1, TEST_MESSAGE_1, 1);
        invalidMessage.messageID = "12345678901"; // 11 characters
        boolean result2 = invalidMessage.checkMessageID();
        assertFalse("Invalid MessageID should return false", result2);
    }

    
    /**
     * Test constructor and auto-generated values
     */
    @Test
    public void testAutoGeneratedValues() {
        System.out.println("Testing auto-generated values");
        
        // Test that all required fields are auto-generated
        assertNotNull("MessageID should be auto-generated", testMessage1.messageID);
        assertNotNull("Message hash should be auto-generated", testMessage1.messageHash);
        assertEquals("Num sent messages should match", 1, testMessage1.numMessagesSent);
        
        // Test second message
        assertNotNull("MessageID should be auto-generated for message 2", testMessage2.messageID);
        assertNotNull("Message hash should be auto-generated for message 2", testMessage2.messageHash);
        assertEquals("Num sent messages should match for message 2", 2, testMessage2.numMessagesSent);
    }

    /**
     * Integration test using the specific test data provided
     */
    @Test
    public void testWithProvidedTestData() {
        System.out.println("Testing with provided test data");
        
        // Test Case 1: Message to Mike (should send successfully)
        assertEquals("Recipient 1 should be valid", TEST_RECIPIENT_1, testMessage1.recipient);
        assertEquals("Message 1 should match", TEST_MESSAGE_1, testMessage1.messageText);
        assertEquals("Message 1 should be valid length", true, TEST_MESSAGE_1.length() <= 250);
        assertEquals("Recipient 1 should pass validation", 1, testMessage1.checkRecipientCell());
        
        // Test Case 2: Message to Keegan (should be discarded due to invalid recipient)
        assertEquals("Recipient 2 should be invalid format", TEST_RECIPIENT_2, testMessage2.recipient);
        assertEquals("Message 2 should match", TEST_MESSAGE_2, testMessage2.messageText);
        assertEquals("Message 2 should be valid length", true, TEST_MESSAGE_2.length() <= 250);
        assertEquals("Recipient 2 should fail validation", 0, testMessage2.checkRecipientCell());
        
        System.out.println("Test Case 1 (Mike): Valid recipient, should send");
        System.out.println("Test Case 2 (Keegan): Invalid recipient, should discard");
    }
}