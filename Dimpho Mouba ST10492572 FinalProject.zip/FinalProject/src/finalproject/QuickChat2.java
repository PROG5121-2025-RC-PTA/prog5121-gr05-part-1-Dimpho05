package finalproject;

//Guided by Chatgpt
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.util.*;
import java.io.*;

class Message {
    public String messageID;
    public int numMessagesSent;
    public String recipient;
    public String messageText;
    public String messageHash;
    public String sender; 
    
  public Message(String sender, String recipient, String messageText, int messageNumber) {
        this.sender = sender;
        this.recipient = recipient;
        this.messageText = messageText;
        this.numMessagesSent = messageNumber;
        this.messageID = MessageID();
        this.messageHash = createMessageHash();
    }
    
    // any random 10 digit number
    public String MessageID() {
        String id = "";
        Random num = new Random();
        for (int i = 0; i < 10; i++) {
            id = id + num.nextInt(10);
        }
        return id;
    }
    
    //making sure the message ID is not more than 10 characters
    public boolean checkMessageID() {
        if (messageID.length() <= 10) {
            return true;
        } else {
            return false;
        }
        
   
    }
    
    // making sure therecipient cell is not more than 12 characters and starts with +27
    public int checkRecipientCell() {
        if (recipient.length() <= 12 && recipient.startsWith("+27")) {
            return 1;
        } else {
            return 0;
        }
    }
    
    // Creating message hash
    //guided by chatGPT
    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.split(" ");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        String hash = firstTwo + ":" + numMessagesSent + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }
    
    public String sentMessage() {
        String[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int choice = JOptionPane.showOptionDialog(null, "What do you want to do?", "Choose", 
                    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        
        if (choice == 0) {
            return "Message sent";
        } else if (choice == 1) {
            return "Message discarded";
        } else if (choice == 2) {
            storeMessage();
            return "Message stored";
        } else {
            return "Cancelled";
        }
    }
    
    // Store message in JSON file
    //guided by ChatGPT
    public void storeMessage() {
        try {
            ArrayList<Message> storedMessages = new ArrayList<Message>();
            File file = new File("messages.json");
            
            if (file.exists()) {
                Scanner scanner = new Scanner(file);
                String jsonContent = "";
                while (scanner.hasNextLine()) {
                    jsonContent += scanner.nextLine();
                }
                scanner.close();
                if (jsonContent.contains("\"messageID\"")) {
                }
            }
            String messageJson = "{\n" +
                "  \"messageID\": \"" + messageID + "\",\n" +
                "  \"sender\": \"" + sender + "\",\n" +
                "  \"numMessagesSent\": " + numMessagesSent + ",\n" +
                "  \"recipient\": \"" + recipient + "\",\n" +
                "  \"messageText\": \"" + messageText + "\",\n" +
                "  \"messageHash\": \"" + messageHash + "\"\n" +
                "}";
            
            // Writing to JSON file
            FileWriter writer;
            if (file.exists() && file.length() > 0) {
                Scanner reader = new Scanner(file);
                String existingContent = "";
                while (reader.hasNextLine()) {
                    existingContent += reader.nextLine() + "\n";
                }
                reader.close();
                
                if (existingContent.trim().equals("[]") || existingContent.trim().equals("")) {
                    // Empty array, adding first message
                    writer = new FileWriter("messages.json");
                    writer.write("[\n" + messageJson + "\n]");
                } else {
                    // Adding to existing messages
                    existingContent = existingContent.replace("]", "," + messageJson + "\n]");
                    writer = new FileWriter("messages.json");
                    writer.write(existingContent);
                }
            } else {
                // Creating new file with first message
                writer = new FileWriter("messages.json");
                writer.write("[\n" + messageJson + "\n]");
            }
            
            writer.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saving message: " + e.getMessage());
        }
    }
}

public class QuickChat2 {
    // Arrays to store user data for up to 5 users
    public static String[] username = new String[5];
    public static String[] password = new String[5];
    public static String[] cellPhone = new String[5];
    public static int count = 0;
    
    public static boolean isLoggedIn = false;
    public static int maxMessages = 0;
    public static int messagesSent = 0;
    public static String currentUser = "";
    
    
    public static ArrayList<Message> sentMessageContents = new ArrayList<Message>();
    public static ArrayList<Message> disregardedMessages = new ArrayList<Message>();
    public static ArrayList<Message> storedMessages = new ArrayList<Message>();
    public static ArrayList<String> messageHashes = new ArrayList<String>();
    public static ArrayList<String> messageIDs = new ArrayList<String>();
    public static ArrayList<Message> allMessages = new ArrayList<Message>();

    public static void main(String[] args) {
        
        loadStoredMessages();
        
        // Creating main registration 
        //Guided by Chatgpt
        JFrame frameRegister = new JFrame("QuickChat");
        frameRegister.setVisible(true);
        frameRegister.setSize(420, 420);
        frameRegister.getContentPane().setBackground(Color.blue);
        frameRegister.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JLabel registerLabel = new JLabel("Welcome,Please register");
        frameRegister.add(registerLabel);
        registerLabel.setForeground(Color.black);
        registerLabel.setBounds(20, 10, 300, 150);
        registerLabel.setVerticalAlignment(JLabel.CENTER);
        registerLabel.setHorizontalAlignment(JLabel.CENTER);
        frameRegister.setLayout(null);
        
        JButton loginButton = new JButton("login");
        frameRegister.add(loginButton);
        loginButton.setBounds(30, 290, 250, 26);
       
        loginButton.addActionListener(new ActionListener() {//Guided by Chatgpt
            @Override
            public void actionPerformed(ActionEvent e) {
               login();// Open login window when clicked
            }
        });
        
        // Username input
        JLabel usernameLabel = new JLabel("username");
        frameRegister.add(usernameLabel);
        usernameLabel.setBounds(50, 120, 150, 20);
        JTextField usernameTextField = new JTextField();
        frameRegister.add(usernameTextField);
        usernameTextField.setBounds(120, 120, 200, 20);
        
        // Password input
        JLabel passwordLabel = new JLabel("password");
        frameRegister.add(passwordLabel);
        passwordLabel.setBounds(50, 140, 150, 50);
        JTextField passwordTextField = new JTextField();
        frameRegister.add(passwordTextField);
        passwordTextField.setBounds(120, 155, 200, 20);
        
        // Cellphone input
        JLabel cellPhoneLabel = new JLabel("cellPhone");
        frameRegister.add(cellPhoneLabel);
        cellPhoneLabel.setBounds(50, 160, 150, 80);
        JTextField cellPhoneTextField = new JTextField();
        frameRegister.add(cellPhoneTextField);
        cellPhoneTextField.setBounds(120, 190, 200, 20);
        
        // Register button 
        JButton registerButton = new JButton("register");
        frameRegister.add(registerButton);
        registerButton.setBounds(30, 260, 250, 26);
        // message label
        JLabel messageLabel = new JLabel();
        frameRegister.add(messageLabel);
        frameRegister.setResizable(false);
        messageLabel.setBounds(20, 300, 300, 50);
        
        //register button 
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               String registerUsername, registerPassword, registerCellPhone;
               
               registerUsername = usernameTextField.getText();
               registerPassword = passwordTextField.getText();
               registerCellPhone = cellPhoneTextField.getText();
               
               
               // Validate user input
               checkUserName(registerUsername);
               checkPasswordComplexity(registerPassword);
               checkCellPhoneNumber(registerCellPhone);
               // registration messages
               messageLabel.setText(registerUser(registerUsername, registerPassword, registerCellPhone));
               JOptionPane.showMessageDialog(null, registerUser(registerUsername, registerPassword, registerCellPhone));
                  
               //Guided by Chatgpt
               if (checkUserName(registerUsername) == false) {
                   JOptionPane.showMessageDialog(null, "Username has not been entered correctly");
               }
               if (checkPasswordComplexity(registerPassword) == false) {
                   JOptionPane.showMessageDialog(null, "Password has not been entered correctly");
               }
               if (checkCellPhoneNumber(registerCellPhone) == false) {
                   JOptionPane.showMessageDialog(null, "CellPhone has not been entered correctly");
               }
              
               if (checkCellPhoneNumber(registerCellPhone) == true && checkPasswordComplexity(registerPassword) == true && checkUserName(registerUsername) == true) {
                   username[count] = registerUsername;
                   password[count] = registerPassword;
                   cellPhone[count] = registerCellPhone;
                   count++;  
               }
            }
        });
    }
    //guided by ChatGPT
    // Loading stored messages from JSON file
    public static void loadStoredMessages() {
        try {
            File file = new File("messages.json");
            if (file.exists()) {
                
                Scanner scanner = new Scanner(file);
                String jsonContent = "";
                while (scanner.hasNextLine()) {
                jsonContent = jsonContent + scanner.nextLine();
                }
                scanner.close();
                
                
                if (jsonContent.contains("\"messageID\"")) {
                    String[] messageParts = jsonContent.split("\\{");
                    for (String part : messageParts) {
                        if (part.contains("messageID")) {
                            
                            // Extract message data 
                            String messageID = extractValue(part, "messageID");
                            String sender = extractValue(part, "sender");
                            String recipient = extractValue(part, "recipient");
                            String messageText = extractValue(part, "messageText");
                            String messageHash = extractValue(part, "messageHash");
                            
                            
                            if (!messageID.isEmpty() && !sender.isEmpty()) {
                                Message storedMsg = new Message(sender, recipient, messageText, 0);
                                storedMsg.messageID = messageID;
                                storedMsg.messageHash = messageHash;
                                storedMessages.add(storedMsg);
                                messageHashes.add(messageHash);
                                messageIDs.add(messageID);
                            }}
                        
                    }
                }
            }
        } catch (Exception e) {
            
            System.out.println("Error loading stored messages: " + e.getMessage());
        }
    }
    
   
    
    public static String extractValue(String json, String key) {
        try {
            String searchFor = "\"" + key + "\": \"";
            int start = json.indexOf(searchFor);
            if (start != -1) {
                start += searchFor.length();
                int end = json.indexOf("\"", start);
                if (end != -1) {
                    return json.substring(start, end);
                }
            }
        } catch (Exception e) {
            
        }
        return "";
    }
    
    //login window
    public static void login() {
        JFrame loginFrame = new JFrame("Login to QuickChat");
        loginFrame.setVisible(true);
        loginFrame.setSize(420, 420);
        loginFrame.getContentPane().setBackground(Color.blue);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JLabel registerLabel = new JLabel("Login");
        loginFrame.add(registerLabel);
        registerLabel.setForeground(Color.black);
        registerLabel.setBounds(20, 50, 250, 60);
        registerLabel.setVerticalAlignment(JLabel.CENTER);
        registerLabel.setHorizontalAlignment(JLabel.CENTER);
        loginFrame.setLayout(null);
        
        //Password input 
        JLabel loginPassword = new JLabel("password");
        loginFrame.add(loginPassword);
        loginPassword.setBounds(50, 100, 150, 100);
        JTextField passwordLogin2 = new JTextField();
        loginFrame.add(passwordLogin2);
        passwordLogin2.setBounds(120, 140, 150, 20);
        loginFrame.setLayout(null);
        
        //Username input 
        JLabel loginusername = new JLabel("username");
        loginFrame.add(loginusername);
        loginusername.setBounds(50, 140, 150, 100);
        JTextField usernameLogin2 = new JTextField();
        loginFrame.add(usernameLogin2);
        usernameLogin2.setBounds(120, 180, 150, 20);
        loginFrame.setLayout(null);
        loginFrame.setResizable(false);
        
        // Login button
        JButton loginButton = new JButton("login");
        loginFrame.add(loginButton);
        loginButton.setBounds(150, 250, 80, 20);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String loginUsername;
                String loginpassword;
                loginUsername = usernameLogin2.getText();
                loginpassword = passwordLogin2.getText();
                
                // Checking if user exists in our arrays
                boolean user = false;
                for (int i = 0; i < count; i++) {
                    if (username[i].equals(loginUsername) && password[i].equals(loginpassword)) {
                     user = true;
                        currentUser = loginUsername; 
                        break; }
                   
                    
                }
                
                if (user) {
                    isLoggedIn = true;
                    JOptionPane.showMessageDialog(null, "Login successful!");
                    loginFrame.dispose(); 
                    startQuickChat(); // Starting QuickChat
                } else {
                    JOptionPane.showMessageDialog(null, "Login failed - user not found");
           }
            }
        });
    
        // back button to go back to registration
        JButton backButton = new JButton("Back to Register");
        loginFrame.add(backButton);
        backButton.setBounds(150, 280, 150, 20);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loginFrame.dispose(); 
            }
        });
    }
    
    //QuickChat after a successful login
    public static void startQuickChat() {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
        
        //how many messages user wants to send
        String input = JOptionPane.showInputDialog("How many messages do you want to send?");
        try {
            maxMessages = Integer.parseInt(input);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Invalid number");
            return;
        }
        
        //menu
        boolean running = true;
        while (running) {
            String menu = "QuickChat Menu:\n" +
                         "1) Send Messages\n" +
                         "2) Display all sent messages\n" +
                         "3) Find longest message\n" +
                         "4) Search by Message ID\n" +
                         "5) Search by Recipient\n" +
                         "6) Delete message by Hash\n" +
                         "7) Full Report\n" +
                         "8) Quit\n\n" +
                         "Messages sent: " + messagesSent + "/" + maxMessages;
            
      String choice = JOptionPane.showInputDialog(menu + "\n\nEnter choice (1-8):");
     
            
            if (choice == null) {
                running = false;
            } else if (choice.equals("1")) {
                if (messagesSent < maxMessages) {
                    sendMessage();
                } else {
                    JOptionPane.showMessageDialog(null, "You reached your message limit!");
                }
            } else if (choice.equals("2")) {
                displayAllSentMessages();
            } else if (choice.equals("3")) {
                findLongestMessage();
            } else if (choice.equals("4")) {
                searchByMessageID();
            } else if (choice.equals("5")) {
                searchByRecipient();
            } else if (choice.equals("6")) {
                deleteByMessageHash();
            } else if (choice.equals("7")) {
                displayFullReport();
            } else if (choice.equals("8")) {
                running = false;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid choice");
            }
        }
        
        //summary
        JOptionPane.showMessageDialog(null, "Total messages sent: " + allMessages.size());
        if (allMessages.size() > 0) {
            String allMessagesText = printMessages();
            JOptionPane.showMessageDialog(null, allMessagesText);
        }
    }
    
    // Sending a message
    public static void sendMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient cell number:");
        if (recipient == null) return;
        
        String messageText = JOptionPane.showInputDialog("Enter message (max 250 characters):");
        if (messageText == null) return;
        
        if (messageText.length() > 250) {
            JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
            return;
        }
        
        Message newMessage = new Message(currentUser, recipient, messageText, messagesSent + 1);
        
        if (newMessage.checkRecipientCell() == 0) {
            JOptionPane.showMessageDialog(null, "Invalid recipient - must be max 12 characters and start with +27");
            return;
        }
        
        String result = newMessage.sentMessage();
        
        if (result.equals("Message sent")) {
            sentMessageContents.add(newMessage);
            messageHashes.add(newMessage.messageHash);
            messageIDs.add(newMessage.messageID);
            allMessages.add(newMessage);
            messagesSent++;
            
            String details = "Message ID: " + newMessage.messageID + "\n" +
                           "Message Hash: " + newMessage.messageHash + "\n" +
                           "Recipient: " + newMessage.recipient + "\n" +
                           "Message: " + newMessage.messageText;
            JOptionPane.showMessageDialog(null, details);
        } else if (result.equals("Message discarded")) {
            disregardedMessages.add(newMessage);
        } else if (result.equals("Message stored")) {
            storedMessages.add(newMessage);
            messageHashes.add(newMessage.messageHash);
            messageIDs.add(newMessage.messageID);
            allMessages.add(newMessage);
            
            String details = "Message ID: " + newMessage.messageID + "\n" +
                           "Message Hash: " + newMessage.messageHash + "\n" +
                           "Recipient: " + newMessage.recipient + "\n" +
                           "Message: " + newMessage.messageText;
            JOptionPane.showMessageDialog(null, details);
        }
        
        JOptionPane.showMessageDialog(null, result);
    }
    
    //showing all sent messages
    public static void displayAllSentMessages() {
        if (sentMessageContents.size() == 0) {
            JOptionPane.showMessageDialog(null, "No sent messages to display.");
            return;
        }
        
        String result = "All Sent Messages:\n";
        for (int i = 0; i < sentMessageContents.size(); i++) {
            Message msg = sentMessageContents.get(i);
            result = result + (i + 1) + ". " + msg.sender + " → " + msg.recipient + "\n";
        }
        JOptionPane.showMessageDialog(null, result);
    }
    
    //showing the longest sent message
    public static void findLongestMessage() {
        if (sentMessageContents.size() == 0) {
            JOptionPane.showMessageDialog(null, "No sent messages to interpret.");
            return;
        }
        
        Message longestMessage = sentMessageContents.get(0);
        for (int i = 1; i < sentMessageContents.size(); i++) {
            if (sentMessageContents.get(i).messageText.length() > longestMessage.messageText.length()) {
                longestMessage = sentMessageContents.get(i);
            }
        }
        
        String result = "Longest Message (" + longestMessage.messageText.length() + " characters):\n\n" +
                       "From: " + longestMessage.sender + "\n" +
                       "To: " + longestMessage.recipient + "\n" +
                       "Message: " + longestMessage.messageText;
        
        JOptionPane.showMessageDialog(null, result);
    }
    
    //Searching by message ID and showing the corresponding recipient and message
    public static void searchByMessageID() {
        String searchID = JOptionPane.showInputDialog("Enter Message ID to search:");
        if (searchID == null) return;
        
        Message foundMessage = null;
        // Search in sent messages
        for (Message msg : sentMessageContents) {
            if (msg.messageID.equals(searchID)) {
                foundMessage = msg;
                break;
            }
        }
        
        // Search in stored messages if not found
        if (foundMessage == null) {
            for (Message msg : storedMessages) {
                if (msg.messageID.equals(searchID)) {
                    foundMessage = msg;
                    break;
               
            }}
        }
        
        if (foundMessage != null) {
            String result = "Message Found:\n\n" +
                           "ID: " + foundMessage.messageID + "\n" +
                           "From: " + foundMessage.sender + "\n" +
                           "Recipient: " + foundMessage.recipient + "\n" +
                           "Message: " + foundMessage.messageText;
            JOptionPane.showMessageDialog(null, result);
        } else {
         JOptionPane.showMessageDialog(null, "Message with ID '" + searchID + "' not found.");
        }
    }
    
    // Search for all the messages sent to a recipient
    public static void searchByRecipient() {
        String searchRecipient = JOptionPane.showInputDialog("Enter Recipient to search:");
        if (searchRecipient == null) return;
        
        ArrayList<Message> foundMessages = new ArrayList<Message>();
        
        // Search in sent messages
        for (Message msg : sentMessageContents) {
            if (msg.recipient.equalsIgnoreCase(searchRecipient)) {
                foundMessages.add(msg);
            }
        }
        
        // Search in stored messages
        for (Message msg : storedMessages) {
            if (msg.recipient.equalsIgnoreCase(searchRecipient)) {
                foundMessages.add(msg);
            }
        }
        
        if (foundMessages.size() > 0) {
            String result = "Messages to " + searchRecipient + " (" + foundMessages.size() + " found):\n\n";
            for (int i = 0; i < foundMessages.size(); i++) {
                Message msg = foundMessages.get(i);
                result = result + (i + 1) + ". From: " + msg.sender + "\n" +
                         "   Message: " + msg.messageText + "\n" +
                         "   ID: " + msg.messageID + "\n\n";
            }
            JOptionPane.showMessageDialog(null, result);
        } else {
            JOptionPane.showMessageDialog(null, "No messages found for recipient: " + searchRecipient);
        }
    }
    
    // Deleting a message using the message hash
    public static void deleteByMessageHash() {
        String searchHash = JOptionPane.showInputDialog("Enter Message Hash to delete:");
        if (searchHash == null) return;
        
        boolean deleted = false;
        
        //delete from sent messages
        for (int i = 0; i < sentMessageContents.size(); i++) {
            if (sentMessageContents.get(i).messageHash.equals(searchHash)) {
                sentMessageContents.remove(i);
                deleted = true;
                break;
            }
        }
        
        //delete from stored messages if not found in sent
        if (!deleted) {
            for (int i = 0; i < storedMessages.size(); i++) {
                if (storedMessages.get(i).messageHash.equals(searchHash)) {
                    storedMessages.remove(i);
                    deleted = true;
                    break;
                }
          }
        }
        
        
        
        // Removing from hash and ID arrays
        if (deleted) {
         messageHashes.remove(searchHash);
           JOptionPane.showMessageDialog(null, "Message deleted successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Message with hash '" + searchHash + "' not found.");
        }
    }
    
    //showing a report that lists the full details of all the sent messages
    public static void displayFullReport() {
        String report = "FULL MESSAGE REPORT  ";
        
        report += "SENT MESSAGES (" + sentMessageContents.size() + "):\n";
        for (int i = 0; i < sentMessageContents.size(); i++) {
            Message msg = sentMessageContents.get(i);
            
          report = report + "Message " + (i + 1) + ":\n";
          report = report + "  ID: " + msg.messageID + "\n";
          report = report + "  Hash: " + msg.messageHash + "\n"; 
          report = report + "  From: " + msg.sender + "\n";
          report = report + "  To: " + msg.recipient + "\n";
          report = report + "  Message: " + msg.messageText + "\n\n";
        }
        
        
report = report + "STORED MESSAGES (" + storedMessages.size() + "):\n";

for (int i = 0; i < storedMessages.size(); i++) {
    Message msg = storedMessages.get(i);  

    
    report = report + "Stored " + (i + 1) + ":\n";

    report = report + "  ID: " + msg.messageID + "\n";
    report = report + "  Hash: " + msg.messageHash + "\n";
    report = report + "  From: " + msg.sender + "\n";
    report = report + "  To: " + msg.recipient + "\n";
    report = report + "  Message: " + msg.messageText + "\n\n";

        }
        
    
report = report + "DISREGARDED MESSAGES (" + disregardedMessages.size() + "):\n";


for (int i = 0; i < disregardedMessages.size(); i++) {
    Message msg = disregardedMessages.get(i);  // Get the current message

    report = report + "Disregarded " + (i + 1) + ":\n";

    report = report + "  From: " + msg.sender + "\n";
    report = report + "  To: " + msg.recipient + "\n";
    report = report + "  Message: " + msg.messageText + "\n\n";
}
        
        
         report = report + "SUMMARY:\n";
         report = report + "Total Sent: " + sentMessageContents.size() + "\n";
         report = report + "Total Stored: " + storedMessages.size() + "\n";
         report = report + "Total Disregarded: " + disregardedMessages.size() + "\n";
         report = report + "Total Message Hashes: " + messageHashes.size() + "\n";
         report = report + "Total Message IDs: " + messageIDs.size();
        
        JOptionPane.showMessageDialog(null, report);
    }
    
    //guided by ChatGPT
    // Print all messages
    public static String printMessages() {
        if (allMessages.size() == 0) {
            return "No messages sent.";
        }
        
        String result = "All Messages:\n\n";
        for (int i = 0; i < allMessages.size(); i++) {
            Message msg = allMessages.get(i);
          
            result = result + "Message " + (i + 1) + ":\n";

         result = result + "ID: " + msg.messageID + "\n";
         result = result + "Hash: " + msg.messageHash + "\n";
         result = result + "From: " + msg.sender + "\n";
         result = result + "Recipient: " + msg.recipient + "\n";
         result = result + "Message: " + msg.messageText + "\n\n";
        }
        return result;
    }
    
    // Returning total messages
    public static int returnTotalMessages() {
        return allMessages.size();
    }
       
    // Check if username is valid (must contain "_" and be max 5 characters)
    public static boolean checkUserName(String username) {
        if ((username.contains("_") && username.length() <= 5)) {// guided by Chatgpt
            return true;
        } else {
            return false;
        }
    }
    
    // Check password complexity
    //Guided by Chatgpt
    public static boolean checkPasswordComplexity(String password) {
        String capitalLetters = ".*[A-Z].*";
        String smallLetters = ".*[a-z].*"; // Fixed the regex
        String special = ".*[!@#$%^&*(),.?\":{}<>|].*";
        String digit = ".*\\d.*";
      
        if (password.length() >= 8 && password.matches(digit) && password.matches(special) && password.matches(smallLetters) && password.matches(capitalLetters)) {
            return true;
        } else {
            return false;
        }
    }
    
    // Validate cellphone number
    //Guided by Chatgpt
    public static boolean checkCellPhoneNumber(String cellphone){
    String saCellPhone = "+27";
    String firstThreeCharacters = cellphone.substring(0,3);
    int fourthDigit = Character.getNumericValue(cellphone.charAt(3));
    if (cellphone.length() >=12 && firstThreeCharacters.equals( saCellPhone) && fourthDigit >=6 && fourthDigit <=8){
    return true;
    }
    else{
    return false;
    }

    }
    
    public static String registerUser(String username,String password, String cellphone){
        if (checkUserName(username) == true && checkPasswordComplexity(password) == true && checkCellPhoneNumber(cellphone) ==true){
            return "successfully registered";
            
        }
        else {
            return "Registration failed";
        }
    }
    //Checking if user credentials are valid
    public static boolean loginUser(String username, String password) {
        if (checkUserName(username )== true && checkPasswordComplexity(password) == true){
            return true;
        }
        else {
            return false;
        } 
    } 
    // Return login status message
    public static String returnLoginStatus(String username, String password){
        if (checkUserName(username )== true && checkPasswordComplexity(password) == true){
            return "You have successfully logged in";
        }
        else {
            return "Failed to login";
    }
    }
}