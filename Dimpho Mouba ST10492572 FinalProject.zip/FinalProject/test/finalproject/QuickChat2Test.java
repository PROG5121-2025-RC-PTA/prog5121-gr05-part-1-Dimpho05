//guided by chatGPT
package finalproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;



public class QuickChat2Test {
    
    
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        QuickChat2.main(args);
        
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testLoadStoredMessages() {
        System.out.println("loadStoredMessages");
        QuickChat2.loadStoredMessages();
        
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testExtractValue() {
        System.out.println("extractValue");
        String json = "";
        String key = "";
        String expResult = "";
        String result = QuickChat2.extractValue(json, key);
        assertEquals(expResult, result);
        
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testLogin() {
        System.out.println("login");
        QuickChat2.login();
        
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testStartQuickChat() {
        System.out.println("startQuickChat");
        QuickChat2.startQuickChat();

        fail("The test case is a prototype.");
    }

    
    @Test
    public void testSendMessage() {
        System.out.println("sendMessage");
        QuickChat2.sendMessage();
        
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testSentMessagesArrayPopulated() {
        System.out.println("Testing Sent Messages Array Population");
        
        // Get sent messages from the system
        String[] sentMessages = QuickChat2.getSentMessages();
        
        // Expected sent messages based on test data
        String expectedMessage1 = "Did you get the cake?";
        String expectedMessage2 = "It is dinner time!";
        
        // Verifying the sent messages array contains expected messages
        boolean containsMessage1 = false;
        boolean containsMessage2 = false;
        
        for (String message : sentMessages) {
            if (message != null && message.equals(expectedMessage1)) {
                containsMessage1 = true;
            }
            if (message != null && message.equals(expectedMessage2)) {
                containsMessage2 = true;
            }
        }
        
        assertTrue("Sent messages should contain: " + expectedMessage1, containsMessage1);
        assertTrue("Sent messages should contain: " + expectedMessage2, containsMessage2);
    }

    
    @Test
    public void testFindLongestMessage() {
        System.out.println("Testing Find Longest Message");
        
        String expectedLongestMessage = "Where are you? You are late! I have asked you to be on time.";
        String actualLongestMessage = QuickChat2.findLongestMessage();
        
        assertEquals("Should return the longest message", expectedLongestMessage, actualLongestMessage);
    }

    
    @Test
    public void testSearchByMessageID() {
        System.out.println("Testing Search by Message ID");
        
        String messageID = "0838884567";
        String expectedMessage = "It is dinner time!";
        
        String actualMessage = QuickChat2.searchByMessageID(messageID);
        
        assertEquals("Should return message for ID: " + messageID, expectedMessage, actualMessage);
    }

    
    @Test
    public void testSearchByRecipient() {
        System.out.println("Testing Search by Recipient");
        
        String recipient = "+27838884567";
        String[] expectedMessages = {
            "Where are you? You are late! I have asked you to be on time.",
            "Ok, I am leaving without you."
        };
        
        String[] actualMessages = QuickChat2.searchByRecipient(recipient);
        
        assertNotNull("Should return messages array", actualMessages);
        assertTrue("Should contain first expected message", 
                   containsMessage(actualMessages, expectedMessages[0]));
        assertTrue("Should contain second expected message", 
                   containsMessage(actualMessages, expectedMessages[1]));
    }

    
    @Test
    public void testDeleteByMessageHash() {
        System.out.println("Testing Delete by Message Hash");
        
       
        String messageToDelete = "Where are you? You are late! I have asked you to be on time.";
        String messageHash = QuickChat2.getMessageHash(messageToDelete);
        
        String expectedResponse = "Message \"Where are you? You are late! I have asked you to be on time\" successfully deleted.";
        String actualResponse = QuickChat2.deleteByMessageHash(String messageHash);
        
        assertEquals("Should return successful deletion message", expectedResponse, actualResponse);
    }

    
    @Test
    public void testDisplayFullReport() {
        System.out.println("Testing Display Full Report");
        
        String report = QuickChat2.displayFullReport();
        
        assertNotNull("Report should not be null", report);
        
        // Verifying report contains expected sent messages
        assertTrue("Report should contain sent message 1", 
                   report.contains("Did you get the cake?"));
        assertTrue("Report should contain sent message 4", 
                   report.contains("It is dinner time!"));
        
        // Verifying report contains recipients for sent messages
        assertTrue("Report should contain recipient for message 1", 
                   report.contains("+27834557896"));
        assertTrue("Report should contain recipient for message 4", 
                   report.contains("0838884567"));
        
        // Verifying report structure contains required fields
        assertTrue("Report should contain Message Hash information", 
                   report.toLowerCase().contains("hash"));
        assertTrue("Report should contain Recipient information", 
                   report.toLowerCase().contains("recipient"));
        assertTrue("Report should contain Message information", 
                   report.toLowerCase().contains("message"));
    }

    
    private boolean containsMessage(String[] messages, String targetMessage) {
        if (messages == null || targetMessage == null) {
            return false;
        }
        
        for (String message : messages) {
            if (message != null && message.equals(targetMessage)) {
                return true;
            }
        }
        return false;
    }

    
    @Test
    public void testPrintMessages() {
        System.out.println("printMessages");
        String expResult = "";
        String result = QuickChat2.printMessages();
        assertEquals(expResult, result);
        
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testReturnTotalMessages() {
        System.out.println("returnTotalMessages");
        int expResult = 5; // Based on 5 test messages
        int result = QuickChat2.returnTotalMessages();
        assertEquals(expResult, result);
    }

    
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        String username = "";
        boolean expResult = false;
        boolean result = QuickChat2.checkUserName(username);
        assertEquals(expResult, result);
        
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String password = "";
        boolean expResult = false;
        boolean result = QuickChat2.checkPasswordComplexity(password);
        assertEquals(expResult, result);
        
        fail("The test case is a prototype.");
    }

    
     
    @Test
    public void testCheckCellPhoneNumber() {
        System.out.println("checkCellPhoneNumber");
        String cellphone = "";
        boolean expResult = false;
        boolean result = QuickChat2.checkCellPhoneNumber(cellphone);
        assertEquals(expResult, result);
        
        fail("The test case is a prototype.");
    }

    
     
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String username = "";
        String password = "";
        String cellphone = "";
        String expResult = "";
        String result = QuickChat2.registerUser(username, password, cellphone);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String username = "";
        String password = "";
        boolean expResult = false;
        boolean result = QuickChat2.loginUser(username, password);
        assertEquals(expResult, result);
        
        fail("The test case is a prototype.");
    }

    
    
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        String username = "";
        String password = "";
        String expResult = "";
        String result = QuickChat2.returnLoginStatus(username, password);
        assertEquals(expResult, result);
        
        fail("The test case is a prototype.");
    }
}