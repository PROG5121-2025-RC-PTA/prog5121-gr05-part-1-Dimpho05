
package login;
//Guided by Chatgpt
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class Login {
    
// Arrays to store user data for up to 5 users    
public static String[] username = new String[5];
public static String[] password = new String[5];
public static String[] cellPhone = new String[5];
public static int count = 0;

    
    public static void main(String[] args) {
        
        // Create main registration 
        JFrame frameRegister = new JFrame("CHATCUBE");//Guided by Chatgpt
        frameRegister.setVisible(true);
        frameRegister.setSize(420,420);
        frameRegister.getContentPane().setBackground(Color.blue);
        frameRegister.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Label to greet users
        JLabel registerLabel = new JLabel("Welcome,Please register");
        frameRegister.add(registerLabel);
        registerLabel.setForeground(Color.black);
        registerLabel.setBounds(20,10,300,150);
        registerLabel.setVerticalAlignment(JLabel.CENTER);
        registerLabel.setHorizontalAlignment(JLabel.CENTER);
        frameRegister.setLayout(null);
        
        // Create login button and handle click event
        JButton loginButton = new JButton("login");
        frameRegister.add(loginButton);
        loginButton.setBounds(30, 290, 250, 26);
       
        loginButton.addActionListener(new ActionListener() {//Guided by Chatgpt
            @Override
            public void actionPerformed(ActionEvent e) {
               login();// Open login window when clicked
            }
        });
        // Username input
        JLabel usernameLabel = new JLabel("username");
        frameRegister.add(usernameLabel);
        usernameLabel.setBounds(50, 120, 150, 20);
        JTextField usernameTextField = new JTextField();
        frameRegister.add(usernameTextField);
        usernameTextField.setBounds(120, 120, 200, 20);
        
        
        // Password input
        JLabel passwordLabel = new JLabel("password");
        frameRegister.add(passwordLabel);
        passwordLabel.setBounds(50, 140, 150, 50);
        JTextField passwordTextField = new JTextField();
        frameRegister.add(passwordTextField);
        passwordTextField.setBounds(120, 155, 200, 20);
        
        
        
        // Cellphone input
        JLabel cellPhoneLabel = new JLabel("cellPhone");
        frameRegister.add(cellPhoneLabel);
        cellPhoneLabel.setBounds(50, 160, 150, 80);
        JTextField cellPhoneTextField = new JTextField();
        frameRegister.add(cellPhoneTextField);
        cellPhoneTextField.setBounds(120, 190, 200, 20);
        
        // Register button and message label
        JButton registerButton = new JButton("register");
        frameRegister.add(registerButton);
        registerButton.setBounds(30, 260, 250, 26);
        JLabel messageLabel = new JLabel();
        frameRegister.add(messageLabel);
        frameRegister.setResizable(false);
        messageLabel.setBounds(20, 300, 300, 50);
        
        // Handle register button click
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //declarations
               String registerUsername,registerPassword,registerCellPhone;
               // Read input values
               registerUsername = usernameTextField.getText();
               registerPassword = passwordTextField.getText();
               registerCellPhone = cellPhoneTextField.getText();
               
               // Validate user input
                 checkUserName(registerUsername);
                checkPasswordComplexity(registerPassword);
                checkCellPhoneNumber(registerCellPhone);
                // Show registration status message
                 messageLabel.setText(registerUser(registerUsername, registerPassword, registerCellPhone));
                  JOptionPane.showMessageDialog(null, registerUser(registerUsername, registerPassword, registerCellPhone));
                  
                  // Show error dialogs for invalid inputs
                  //Guided by Chatgpt
                 if (checkUserName(registerUsername) == false){
                     JOptionPane.showMessageDialog(null, "Username has not been entered correctly");
                     
                 }
                 if ( checkPasswordComplexity(registerPassword) == false) {
                     JOptionPane.showMessageDialog(null, "Password has not been entered correctly");
                }
                 
                 if (checkCellPhoneNumber(registerCellPhone) == false) {
                      JOptionPane.showMessageDialog(null, "CellPhone has not been entered correctly");
                    
                }
              
                 // If all inputs are valid, save user info   
                if (checkCellPhoneNumber(registerCellPhone) == true && checkPasswordComplexity(registerPassword) == true && checkUserName(registerUsername) == true){
              
                    username[count] = registerUsername;
                  password[count] = registerPassword;
                  cellPhone[count]= registerCellPhone;
                          
                    count ++;  
                }
                
            }

            private String registeruser(String registerUsername, String registerPassword, String registerCellPhone) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
        
        
     
    }
    // Method to create login window
    public static void login(){
        JFrame loginFrame = new JFrame("LOGIN TO CHATCUBE");
        loginFrame .setVisible(true);
        loginFrame .setSize(420,420);
        loginFrame .getContentPane().setBackground(Color.blue);
        loginFrame .setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Login form elements
        JLabel registerLabel = new JLabel("Login");
        loginFrame.add(registerLabel);
        registerLabel.setForeground(Color.black);
        registerLabel.setBounds(20,50,250,60);
        registerLabel.setVerticalAlignment(JLabel.CENTER);
        registerLabel.setHorizontalAlignment(JLabel.CENTER);
        loginFrame.setLayout(null);
        
        // Password input for login
        JLabel loginPassword = new JLabel("password");
        loginFrame.add(loginPassword);
        loginPassword.setBounds(50, 100, 150, 100);
        JTextField passwordLogin2 = new JTextField();
        loginFrame.add(passwordLogin2);
        passwordLogin2.setBounds(120, 140, 150, 20);
        loginFrame.setLayout(null);
        
        // Username input for login
        JLabel loginusername = new JLabel("username");
        loginFrame.add(loginusername);
        loginusername.setBounds(50, 140, 150, 100);
        JTextField usernameLogin2 = new JTextField();
        loginFrame.add(usernameLogin2);
        usernameLogin2.setBounds(120, 180, 150, 20);
        loginFrame.setLayout(null);
        loginFrame.setResizable(false);
        
        // Login button
        JButton loginButton = new JButton("login");
        loginFrame.add(loginButton);
        loginButton.setBounds(150, 250, 80, 20);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              String loginUsername;
              String loginpassword;
              loginUsername = usernameLogin2.getText();
              loginpassword = passwordLogin2.getText();
                loginUser(loginUsername, loginpassword);
                JOptionPane.showMessageDialog(null, returnLoginStatus(loginUsername, loginpassword));
            }
        });
    }
    
       
     // Check if username is valid (must contain "_" and be max 5 characters)
    public static boolean checkUserName(String username){
        if ((username.contains("_" ) && username.length() <=5)){// guided by Chatgpt
            return true;
        
        }
        else{
            return false;
        }
    }
    // Check password complexity
    //Guided by Chatgpt
    public static boolean checkPasswordComplexity(String password){
        String capitalLetters = ".*[A-Z].*";
        String smallLetters =".[a-z].*";
        String special = ".*[!@#$%^&*(),.?\":{}<>|].*";
        String digit = ".*\\d.*";
      
        if (password.length() >=8 && password.matches(digit) && password.matches(special) && password.matches(smallLetters) && password.matches(capitalLetters)){
            return true;
                    
        }
    
    else{
    return false;
}
} 
    // Validate cellphone number 
    //Guided by Chatgpt
    public static boolean checkCellPhoneNumber(String cellphone){
        String saCellPhone = "+27";
        String firstThreeCharacters = cellphone.substring(0,3);
        int fourthDigit = Character.getNumericValue(cellphone.charAt(3));
       if (cellphone.length() >=12 && firstThreeCharacters.equals( saCellPhone) && fourthDigit >=6 && fourthDigit <=8){
           return true;
       } 
       else{
       return false;
       }
       
       
    }
    // Attempt to register user and return result message
    public static String registerUser(String username,String password, String cellphone){
        if (checkUserName(username) == true && checkPasswordComplexity(password) == true && checkCellPhoneNumber(cellphone) ==true){
            return "successfully registered";
            
        }
        else {
            return "Registration failed";
        }
    }
    // Check if user credentials are valid
    public static boolean loginUser(String username, String password) {
        if (checkUserName(username )== true && checkPasswordComplexity(password) == true){
            return true;
        }
        else {
            return false;
        } 
            
    
    } 
    // Return login status message
    public static String returnLoginStatus(String username, String password){
        if (checkUserName(username )== true && checkPasswordComplexity(password) == true){
            return "You have successfully logged in";
        }
        else {
            return "Failed to login";
    }
}
}