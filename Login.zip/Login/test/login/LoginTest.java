/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package login;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
public class LoginTest {

    
    

    /**
     * Test of checkUserName method, of class Login.
     */
    @Test
    public void CheckUserName() {
        
        String username = "kyl_1";
        
        boolean result = Login.checkUserName(username);
        assertTrue( result);
         String username02 = "kyle!!!!";
         boolean result02 = Login.checkUserName(username02);
         assertFalse(result02);
    }
    

    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexity() {
        
        String password = "Ch&&sec@ke99!";
       
        boolean result = Login.checkPasswordComplexity(password);
        assertTrue( result);
        
                String password02 = "password";
       
        boolean result02 = Login.checkPasswordComplexity(password02);
        assertFalse( result02);

    }

    /**
     * Test of checkCellPhoneNumber method, of class Login.
     */
    @Test
    public void testCheckCellPhoneNumber() {
        
        String cellphone = "+27838968976";
        
        boolean result = Login.checkCellPhoneNumber(cellphone);
        assertTrue (result);
        
        String cellphone02 = "08966553";
        
        boolean result02 = Login.checkCellPhoneNumber(cellphone02);
        assertFalse (result02);
        
    }

    /**
     * Test of registerUser method, of class Login.
     */
    @Test
    public void testRegisterUser() {
        
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        String cellphone = "+27838968976";
        String expResult = "successfully registered";
        String result = Login.registerUser(username, password, cellphone);
        assertEquals(expResult, result);
        
        String username02 = "kyle!!!!";
        String password02 = "password";
        String cellphone02 = "08966553";
        String expResult02 = "Registration failed";
        String result02 = Login.registerUser(username02, password02, cellphone02);
        assertEquals(expResult02, result02);
        
    }

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        
        boolean result = Login.loginUser(username, password);
        assertTrue( result);
        
        String username02 = "kyle!!!!";
        String password02 = "password";
        
        boolean result02 = Login.loginUser(username02, password02);
        assertFalse( result02);
        
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        String expResult = "You have successfully logged in";
        String result = Login.returnLoginStatus(username, password);
        assertEquals(expResult, result);
        
        String username02 = "kyle!!!!";
        String password02 = "password";
        String expResult02 = "Failed to login";
        String result02 = Login.returnLoginStatus(username02, password02);
        assertEquals(expResult02, result02);
        
    }
    
}
